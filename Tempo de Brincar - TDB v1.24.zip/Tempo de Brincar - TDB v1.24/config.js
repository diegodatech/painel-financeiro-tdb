window.TDB_CONFIG={
  build: "tdb-20261021-tdb-v1-24",
  buildLabel: "TDB\u00a0v1.24",
  appsScriptUrl: "https://script.google.com/macros/s/AKfycbw0CRh3ZyFfQkjRz4vRhymlBd489xDWvswt4NlZt4nc_Lf6ZoDlTQh11OfTctiJaxnnTA/exec"
};
